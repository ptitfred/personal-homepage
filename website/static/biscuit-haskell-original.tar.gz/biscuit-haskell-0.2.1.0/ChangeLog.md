# Changelog for biscuit-haskell

## 0.1.1.0

Bugfix for `serializeB64` and `serializeHex`.

## 0.1.0.0

Basic biscuit support.
